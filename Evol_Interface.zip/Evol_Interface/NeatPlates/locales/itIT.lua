local L = LibStub("AceLocale-3.0"):NewLocale("NeatPlates", "itIT")
if not L then return end


L["CLASSIC_DURATION_SEC_PATTERN"] = "([0-9]+%.?[0-9]?)%ss"
