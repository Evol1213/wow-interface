if  (GetLocale() == "esES") then
--
-- Display strings
--

-- tooltip strings
-- error messages



end
