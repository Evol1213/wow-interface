if  (GetLocale() == "zhCN" or GetLocale() == "zhTW") then

-- Contributors: 

--
-- Display strings
--

-- tooltip strings
-- error messages



end
